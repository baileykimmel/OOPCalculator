﻿public class Solver : ISolve
{
    string totalstring;


    public Solver()
    {
        totalstring = "";

    }

    public void Accumulate(string s)
    {
        totalstring += s;
    }

    public void Clear()
    {
        totalstring = "";
    }

    public double Solve()
    {
        Stack<double> numbers = new Stack<double>();
        Stack<char> operators = new Stack<char>();

        //loops thru each element of the string
        for (int i = 0; i < totalstring.Length; i++)
        {
            //checks for middle or leading negatives
            if (totalstring[i] == '-' && (i == 0 || IsOperator(totalstring[i - 1])))
            {
                i++;
                double num = 0;
                while (i < totalstring.Length && char.IsDigit(totalstring[i]))
                {
                    //converts to real number
                    num = num * 10 + (totalstring[i] - '0');
                    i++;
                }
                i--;
                //adds neg num to stack
                numbers.Push(num * -1);
            }
            //decimal case
            else if (char.IsDigit(totalstring[i]) || totalstring[i] == '.')
            {
                double num = 0;
                double decimalPlace = 0.1;
                bool isdecimal = false;
                //checks for decimals and surrounding nums
                while (i < totalstring.Length && char.IsDigit(totalstring[i]) || (!isdecimal && totalstring[i] == '.'))
                {

                    if (totalstring[i] == '.')
                    {
                        isdecimal = true;
                    }
                    else if (!isdecimal)
                    {
                        num = num * 10 + (totalstring[i] - '0');
                    }
                    else
                    {   //makes into real number
                        num += (totalstring[i] - '0') * decimalPlace;
                        decimalPlace *= 0.1;
                    }
                    i++;


                }
                i--;
                numbers.Push(num);
            }
            else if (IsOperator(totalstring[i]))
            {
                //pops from the stacks and finds a result
                while (operators.Count > 0 && Order(operators.Peek(), totalstring[i]))
                {
                    double operand2 = numbers.Pop();
                    double operand1 = numbers.Pop();
                    char op = operators.Pop();
                    double result = MathIt(operand1, operand2, op);
                    numbers.Push(result);
                }
                operators.Push(totalstring[i]);
            }
        }


        //pops from the stacks and finds a result
        while (operators.Count > 0)
        {
            double operand2 = numbers.Pop();
            double operand1 = numbers.Pop();
            char op = operators.Pop();
            double result = MathIt(operand1, operand2, op);
            numbers.Push(result);
        }

        return numbers.Pop();
    }

    //order of operations methonds
    private static bool Order(char op1, char op2)
    {
        int precedence1 = Order2(op1);
        int precedence2 = Order2(op2);
        return precedence1 >= precedence2;
    }

    private static int Order2(char op)
    {
        switch (op)
        {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
            case '%':
                return 2;
            default:
                throw new ArgumentException("Invalid operator: " + op);
        }
    }

    //returns solved math equations
    private static double MathIt(double operand1, double operand2, char op)
    {
        switch (op)
        {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                return operand1 / operand2;
            case '%':
                return operand1 % operand2;
            default:
                throw new ArgumentException("Invalid operator: " + op);
        }
    }

    //checks if something is an operator
    private static bool IsOperator(char c)
    {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '%';
    }
}