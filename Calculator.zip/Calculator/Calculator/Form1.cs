

using System;
using System.Data;
using System.Linq.Expressions;
using System.Reflection.Metadata.Ecma335;

namespace Calculator
{

    public partial class Form1 : Form
    {
        Solver solveit = new Solver();
        string totaldisplay;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) // number 1
        {
            solveit.Accumulate("1");
            totaldisplay += "1";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";

        }

        private void button2_Click(object sender, EventArgs e) //number 2
        {
            solveit.Accumulate("2");
            totaldisplay += "2";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button3_Click(object sender, EventArgs e) //number 3
        {
            solveit.Accumulate("3");
            totaldisplay += "3";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button4_Click(object sender, EventArgs e) //number 4
        {
            solveit.Accumulate("4");
            totaldisplay += "4";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button5_Click(object sender, EventArgs e) //number 5
        {
            solveit.Accumulate("5");
            totaldisplay += "5";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button6_Click(object sender, EventArgs e) //number 6
        {
            solveit.Accumulate("6");
            totaldisplay += "6";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button7_Click(object sender, EventArgs e) //number 7
        {
            solveit.Accumulate("7");
            totaldisplay += "7";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button8_Click(object sender, EventArgs e) //number 8
        {
            solveit.Accumulate("8");
            totaldisplay += "8";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button9_Click(object sender, EventArgs e) //number 9
        {
            solveit.Accumulate("9");
            totaldisplay += "9";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button10_Click(object sender, EventArgs e) //number 0
        {
            solveit.Accumulate("0");
            totaldisplay += "0";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button11_Click(object sender, EventArgs e) //decimal
        {
            solveit.Accumulate(".");
            totaldisplay += ".";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button15_Click(object sender, EventArgs e) //AC
        {
            textBox1.Text = " ";
            solveit.Clear();
            totaldisplay = " " + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button14_Click(object sender, EventArgs e) //+/-
        {
            solveit.Accumulate("-");
            totaldisplay += "-";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button13_Click(object sender, EventArgs e) //%
        {
            solveit.Accumulate("%");
            totaldisplay += "%";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button12_Click(object sender, EventArgs e) //divide
        {
            solveit.Accumulate("/");
            totaldisplay += "/";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------" ;
        }

        private void button19_Click(object sender, EventArgs e) //plus
        {
            solveit.Accumulate("+");
            totaldisplay += "+";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button18_Click(object sender, EventArgs e) //minus
        {
            solveit.Accumulate("-");
            totaldisplay += "-";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";
        }

        private void button16_Click(object sender, EventArgs e) //multiply
        {
            solveit.Accumulate("*");
            totaldisplay += "*";
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------";

        }

        private void button17_Click(object sender, EventArgs e) //equals
        {
            solveit.Accumulate("=");
            textBox1.Text = totaldisplay + "=";
            
            double result = solveit.Solve();
            textBox1.Text = totaldisplay + Environment.NewLine + "--------------------------------------------------------------" + Environment.NewLine + Convert.ToString(result);

        }

    }

}




