﻿using System;

public class Solver, ISolve
{
	void Accumulate (string s)
	{


	}

	void Clear()
	{


	}
	
	double Solve()
	{


	}
}
